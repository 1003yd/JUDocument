package kr.or.ju.myPage;

public class MyPageDao {

}
