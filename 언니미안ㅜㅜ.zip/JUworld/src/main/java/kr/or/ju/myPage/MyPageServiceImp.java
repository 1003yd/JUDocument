package kr.or.ju.myPage;

public interface MyPageServiceImp {

}
