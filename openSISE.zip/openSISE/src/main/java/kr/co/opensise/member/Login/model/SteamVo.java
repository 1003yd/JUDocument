package kr.co.opensise.member.Login.model;

public class SteamVo {
	private int favor_no;
	private int favor_mem;
	private String favor_gu;
	private String favor_dong;
	private String favor_zip;
	private String favor_rd;
	private String favor_ty;
	private String artcl_gu;
	private String artcl_dong;
	private String artcl_zip;
	private String artcl_rd;
	private String artcl_bc;
	private String artcl_complx;
	private String artcl_nm;
	private String artcl_ty;
	private String artcl_prps_pls;
	private String dl_gu;
	private String dl_dong;
	private String dl_zip;
	private String dl_rd;
	private String dl_price;
	private String dl_depos;
	private String dl_rnt;
	private String dl_ty;
	
	public  SteamVo(){
	}
	
	public int getFavor_no() {
		return favor_no;
	}
	public void setFavor_no(int favor_no) {
		this.favor_no = favor_no;
	}
	public int getFavor_mem() {
		return favor_mem;
	}
	public void setFavor_mem(int favor_mem) {
		this.favor_mem = favor_mem;
	}
	public String getFavor_gu() {
		return favor_gu;
	}
	public void setFavor_gu(String favor_gu) {
		this.favor_gu = favor_gu;
	}
	public String getFavor_dong() {
		return favor_dong;
	}
	public void setFavor_dong(String favor_dong) {
		this.favor_dong = favor_dong;
	}
	public String getFavor_zip() {
		return favor_zip;
	}
	public void setFavor_zip(String favor_zip) {
		this.favor_zip = favor_zip;
	}
	public String getFavor_rd() {
		return favor_rd;
	}
	public void setFavor_rd(String favor_rd) {
		this.favor_rd = favor_rd;
	}
	public String getFavor_ty() {
		return favor_ty;
	}
	public void setFavor_ty(String favor_ty) {
		this.favor_ty = favor_ty;
	}
	public String getArtcl_gu() {
		return artcl_gu;
	}
	public void setArtcl_gu(String artcl_gu) {
		this.artcl_gu = artcl_gu;
	}
	public String getArtcl_dong() {
		return artcl_dong;
	}
	public void setArtcl_dong(String artcl_dong) {
		this.artcl_dong = artcl_dong;
	}
	public String getArtcl_zip() {
		return artcl_zip;
	}
	public void setArtcl_zip(String artcl_zip) {
		this.artcl_zip = artcl_zip;
	}
	public String getArtcl_rd() {
		return artcl_rd;
	}
	public void setArtcl_rd(String artcl_rd) {
		this.artcl_rd = artcl_rd;
	}
	public String getArtcl_bc() {
		return artcl_bc;
	}
	public void setArtcl_bc(String artcl_bc) {
		this.artcl_bc = artcl_bc;
	}
	public String getArtcl_complx() {
		return artcl_complx;
	}
	public void setArtcl_complx(String artcl_complx) {
		this.artcl_complx = artcl_complx;
	}
	public String getArtcl_nm() {
		return artcl_nm;
	}
	public void setArtcl_nm(String artcl_nm) {
		this.artcl_nm = artcl_nm;
	}
	public String getArtcl_ty() {
		return artcl_ty;
	}
	public void setArtcl_ty(String artcl_ty) {
		this.artcl_ty = artcl_ty;
	}
	public String getArtcl_prps_pls() {
		return artcl_prps_pls;
	}
	public void setArtcl_prps_pls(String artcl_prps_pls) {
		this.artcl_prps_pls = artcl_prps_pls;
	}
	public String getDl_gu() {
		return dl_gu;
	}
	public void setDl_gu(String dl_gu) {
		this.dl_gu = dl_gu;
	}
	public String getDl_dong() {
		return dl_dong;
	}
	public void setDl_dong(String dl_dong) {
		this.dl_dong = dl_dong;
	}
	public String getDl_zip() {
		return dl_zip;
	}
	public void setDl_zip(String dl_zip) {
		this.dl_zip = dl_zip;
	}
	public String getDl_rd() {
		return dl_rd;
	}
	public void setDl_rd(String dl_rd) {
		this.dl_rd = dl_rd;
	}
	public String getDl_ty() {
		return dl_ty;
	}
	public void setDl_ty(String dl_ty) {
		this.dl_ty = dl_ty;
	}
	public String getDl_price() {
		return dl_price;
	}
	public void setDl_price(String dl_price) {
		this.dl_price = dl_price;
	}
	public String getDl_depos() {
		return dl_depos;
	}
	public void setDl_depos(String dl_depos) {
		this.dl_depos = dl_depos;
	}
	public String getDl_rnt() {
		return dl_rnt;
	}
	public void setDl_rnt(String dl_rnt) {
		this.dl_rnt = dl_rnt;
	}
	
	
	
}
