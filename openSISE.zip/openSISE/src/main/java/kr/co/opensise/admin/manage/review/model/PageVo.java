package kr.co.opensise.admin.manage.review.model;

public class PageVo {
	
	private int page;
	private int pageSize;
	private String searchNm;
	private String selBox;
	
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getSearchNm() {
		return searchNm;
	}
	public void setSearchNm(String searchNm) {
		this.searchNm = searchNm;
	}
	public String getSelBox() {
		return selBox;
	}
	public void setSelBox(String selBox) {
		this.selBox = selBox;
	}
	@Override
	public String toString() {
		return "PageVo [page=" + page + ", pageSize=" + pageSize + ", searchNm=" + searchNm + ", selBox=" + selBox
				+ "]";
	}
	
	
	
	
	

}
