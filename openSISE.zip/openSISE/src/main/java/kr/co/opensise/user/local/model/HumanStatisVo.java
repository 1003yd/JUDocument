package kr.co.opensise.user.local.model;

public class HumanStatisVo {
	private String hs_dong;
	private String hs_gndr;
	private String hs_age_grp;
	private String hs_date;
	private int hs_hm_no;
	private String dong;
	private String hs_gndrf;
	private String hs_gndrm;
	private String hs_dat;
	
	
	public String getHs_dong() {
		return hs_dong;
	}
	public void setHs_dong(String hs_dong) {
		this.hs_dong = hs_dong;
	}
	public String getHs_gndr() {
		return hs_gndr;
	}
	public void setHs_gndr(String hs_gndr) {
		this.hs_gndr = hs_gndr;
	}
	public String getHs_age_grp() {
		return hs_age_grp;
	}
	public void setHs_age_grp(String hs_age_grp) {
		this.hs_age_grp = hs_age_grp;
	}
	public String getHs_date() {
		return hs_date;
	}
	public void setHs_date(String hs_date) {
		this.hs_date = hs_date;
	}
	public int getHs_hm_no() {
		return hs_hm_no;
	}
	public void setHs_hm_no(int hs_hm_no) {
		this.hs_hm_no = hs_hm_no;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getHs_gndrf() {
		return hs_gndrf;
	}
	public void setHs_gndrf(String hs_gndrf) {
		this.hs_gndrf = hs_gndrf;
	}
	public String getHs_gndrm() {
		return hs_gndrm;
	}
	public void setHs_gndrm(String hs_gndrm) {
		this.hs_gndrm = hs_gndrm;
	}
	public String getHs_dat() {
		return hs_dat;
	}
	public void setHs_dat(String hs_dat) {
		this.hs_dat = hs_dat;
	}
	
	

}
