package kr.co.opensise.member.login.dao;

import static org.junit.Assert.*;

import javax.servlet.http.HttpSession;

import org.junit.Test;

import kr.co.opensise.member.Login.model.MemberVo;

public class MemberSessionTest {

	@Test
	public void memberSessionTest() {
		
	}

}
