package kr.or.ju.main;

public interface MainDaoImp {

}
