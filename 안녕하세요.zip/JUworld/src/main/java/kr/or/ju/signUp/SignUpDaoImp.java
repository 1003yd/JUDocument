package kr.or.ju.signUp;

public interface SignUpDaoImp {

}
